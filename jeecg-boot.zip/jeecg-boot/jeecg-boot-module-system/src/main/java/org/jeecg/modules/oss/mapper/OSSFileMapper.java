package org.jeecg.modules.oss.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.jeecg.modules.oss.entity.OSSFile;

public interface OSSFileMapper extends BaseMapper<OSSFile> {

}

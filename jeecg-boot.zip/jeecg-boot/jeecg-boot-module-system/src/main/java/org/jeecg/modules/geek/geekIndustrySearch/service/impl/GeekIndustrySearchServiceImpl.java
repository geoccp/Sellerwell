package org.jeecg.modules.geek.geekIndustrySearch.service.impl;

import org.jeecg.modules.geek.geekIndustrySearch.entity.GeekIndustrySearch;
import org.jeecg.modules.geek.geekIndustrySearch.mapper.GeekIndustrySearchMapper;
import org.jeecg.modules.geek.geekIndustrySearch.service.IGeekIndustrySearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

/**
 * @Description: geek_industry_search
 * @Author: jeecg-boot
 * @Date: 2022-01-23
 * @Version: V1.0
 */
@Service
public class GeekIndustrySearchServiceImpl extends ServiceImpl<GeekIndustrySearchMapper, GeekIndustrySearch> implements IGeekIndustrySearchService {
    @Autowired
    private GeekIndustrySearchMapper industrySearchMapper;

    public boolean deleteTable() {
       return industrySearchMapper.deleteTable();
    }
}

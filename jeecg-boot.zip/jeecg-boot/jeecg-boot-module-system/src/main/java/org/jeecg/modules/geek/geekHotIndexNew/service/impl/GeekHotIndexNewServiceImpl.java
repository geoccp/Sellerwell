package org.jeecg.modules.geek.geekHotIndexNew.service.impl;

import org.jeecg.modules.geek.geekHotIndexNew.entity.GeekHotIndexNew;
import org.jeecg.modules.geek.geekHotIndexNew.mapper.GeekHotIndexNewMapper;
import org.jeecg.modules.geek.geekHotIndexNew.service.IGeekHotIndexNewService;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

/**
 * @Description: geek_hot_index_new
 * @Author: jeecg-boot
 * @Date:   2022-05-09
 * @Version: V1.0
 */
@Service
public class GeekHotIndexNewServiceImpl extends ServiceImpl<GeekHotIndexNewMapper, GeekHotIndexNew> implements IGeekHotIndexNewService {

}

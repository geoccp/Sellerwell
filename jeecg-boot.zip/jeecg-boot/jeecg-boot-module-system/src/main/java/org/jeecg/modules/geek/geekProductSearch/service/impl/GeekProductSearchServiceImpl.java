package org.jeecg.modules.geek.geekProductSearch.service.impl;

import org.jeecg.modules.geek.geekProductSearch.entity.GeekProductSearch;
import org.jeecg.modules.geek.geekProductSearch.mapper.GeekProductSearchMapper;
import org.jeecg.modules.geek.geekProductSearch.service.IGeekProductSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

/**
 * @Description: geek_product_search
 * @Author: jeecg-boot
 * @Date: 2022-01-23
 * @Version: V1.0
 */
@Service
public class GeekProductSearchServiceImpl extends ServiceImpl<GeekProductSearchMapper, GeekProductSearch> implements IGeekProductSearchService {
    @Autowired
    private GeekProductSearchMapper productSearchMapper;

    public boolean deleteTable() {
       return productSearchMapper.deleteTable();
    }
}

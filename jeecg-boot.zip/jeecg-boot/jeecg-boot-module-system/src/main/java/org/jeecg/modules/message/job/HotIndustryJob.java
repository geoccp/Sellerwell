package org.jeecg.modules.message.job;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.jeecg.modules.selenium.GetPostController;
import org.jeecg.modules.selenium.SellerwellController;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Slf4j
public class HotIndustryJob implements Job {

    @Autowired
    private GetPostController getPostController;

    @SneakyThrows
    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        getPostController.industrySearch();
        getPostController.productSearch();

    }

}

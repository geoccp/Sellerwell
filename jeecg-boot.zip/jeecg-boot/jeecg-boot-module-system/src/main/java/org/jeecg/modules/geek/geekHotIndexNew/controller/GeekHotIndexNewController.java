package org.jeecg.modules.geek.geekHotIndexNew.controller;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;
import org.jeecg.common.api.vo.Result;
import org.jeecg.common.system.query.QueryGenerator;
import org.jeecg.common.util.DateUtils;
import org.jeecg.common.util.RestUtil;
import org.jeecg.common.util.oConvertUtils;
import org.jeecg.modules.geek.geekHotIndexNew.entity.GeekHotIndexNew;
import org.jeecg.modules.geek.geekHotIndexNew.service.IGeekHotIndexNewService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.extern.slf4j.Slf4j;

import org.jeecg.modules.geek.geekProductSearch.entity.GeekProductSearch;
import org.jeecgframework.poi.excel.ExcelImportUtil;
import org.jeecgframework.poi.excel.def.NormalExcelConstants;
import org.jeecgframework.poi.excel.entity.ExportParams;
import org.jeecgframework.poi.excel.entity.ImportParams;
import org.jeecgframework.poi.excel.view.JeecgEntityExcelView;
import org.jeecg.common.system.base.controller.JeecgController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import com.alibaba.fastjson.JSON;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.jeecg.common.aspect.annotation.AutoLog;

/**
 * @Description: geek_hot_index_new
 * @Author: jeecg-boot
 * @Date: 2022-05-09
 * @Version: V1.0
 */
@Api(tags = "geek_hot_index_new")
@RestController
@RequestMapping("/geekHotIndexNew/geekHotIndexNew")
@Slf4j
public class GeekHotIndexNewController extends JeecgController<GeekHotIndexNew, IGeekHotIndexNewService> {
    @Autowired
    private IGeekHotIndexNewService geekHotIndexNewService;

    /**
     * 分页列表查询
     *
     * @param geekHotIndexNew
     * @param pageNo
     * @param pageSize
     * @param req
     * @return
     */
    @AutoLog(value = "geek_hot_index_new-分页列表查询")
    @ApiOperation(value = "geek_hot_index_new-分页列表查询", notes = "geek_hot_index_new-分页列表查询")
    @GetMapping(value = "/list")
    public Result<?> queryPageList(GeekHotIndexNew geekHotIndexNew,
                                   @RequestParam(name = "pageNo", defaultValue = "1") Integer pageNo,
                                   @RequestParam(name = "pageSize", defaultValue = "10") Integer pageSize,
                                   HttpServletRequest req) {
        QueryWrapper<GeekHotIndexNew> queryWrapper = QueryGenerator.initQueryWrapper(geekHotIndexNew, req.getParameterMap());
        Page<GeekHotIndexNew> page = new Page<GeekHotIndexNew>(pageNo, pageSize);
        IPage<GeekHotIndexNew> pageList = geekHotIndexNewService.page(page, queryWrapper);
        return Result.OK(pageList);
    }

    /**
     * 添加
     *
     * @param geekHotIndexNew
     * @return
     */
    @AutoLog(value = "geek_hot_index_new-添加")
    @ApiOperation(value = "geek_hot_index_new-添加", notes = "geek_hot_index_new-添加")
    @PostMapping(value = "/add")
    public Result<?> add(@RequestBody GeekHotIndexNew geekHotIndexNew) {
        geekHotIndexNewService.save(geekHotIndexNew);
        return Result.OK("添加成功！");
    }

    /**
     * 编辑
     *
     * @param geekHotIndexNew
     * @return
     */
    @AutoLog(value = "geek_hot_index_new-编辑")
    @ApiOperation(value = "geek_hot_index_new-编辑", notes = "geek_hot_index_new-编辑")
    @PutMapping(value = "/edit")
    public Result<?> edit(@RequestBody GeekHotIndexNew geekHotIndexNew) {
        geekHotIndexNewService.updateById(geekHotIndexNew);
        return Result.OK("编辑成功!");
    }

    /**
     * 通过id删除
     *
     * @param id
     * @return
     */
    @AutoLog(value = "geek_hot_index_new-通过id删除")
    @ApiOperation(value = "geek_hot_index_new-通过id删除", notes = "geek_hot_index_new-通过id删除")
    @DeleteMapping(value = "/delete")
    public Result<?> delete(@RequestParam(name = "id", required = true) String id) {
        geekHotIndexNewService.removeById(id);
        return Result.OK("删除成功!");
    }

    /**
     * 批量删除
     *
     * @param ids
     * @return
     */
    @AutoLog(value = "geek_hot_index_new-批量删除")
    @ApiOperation(value = "geek_hot_index_new-批量删除", notes = "geek_hot_index_new-批量删除")
    @DeleteMapping(value = "/deleteBatch")
    public Result<?> deleteBatch(@RequestParam(name = "ids", required = true) String ids) {
        this.geekHotIndexNewService.removeByIds(Arrays.asList(ids.split(",")));
        return Result.OK("批量删除成功!");
    }

    /**
     * 通过id查询
     *
     * @param id
     * @return
     */
    @AutoLog(value = "geek_hot_index_new-通过id查询")
    @ApiOperation(value = "geek_hot_index_new-通过id查询", notes = "geek_hot_index_new-通过id查询")
    @GetMapping(value = "/queryById")
    public Result<?> queryById(@RequestParam(name = "id", required = true) String id) {
        GeekHotIndexNew geekHotIndexNew = geekHotIndexNewService.getById(id);
        if (geekHotIndexNew == null) {
            return Result.error("未找到对应数据");
        }
        return Result.OK(geekHotIndexNew);
    }

    /**
     * 导出excel
     *
     * @param request
     * @param geekHotIndexNew
     */
    @RequestMapping(value = "/exportXls")
    public ModelAndView exportXls(HttpServletRequest request, GeekHotIndexNew geekHotIndexNew) {
        return super.exportXls(request, geekHotIndexNew, GeekHotIndexNew.class, "geek_hot_index_new");
    }

    /**
     * 通过excel导入数据
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/importExcel", method = RequestMethod.POST)
    public Result<?> importExcel(HttpServletRequest request, HttpServletResponse response) {
        return super.importExcel(request, response, GeekHotIndexNew.class);
    }


    /**
     * 产品分析 产品搜索
     *
     * @throws InterruptedException
     */
    @GetMapping(value = "/getGeekHotIndex")
    public void productSearch(
            @RequestParam(name = "tocken", required = true) String tocken) throws InterruptedException {
        Date startDate = new Date();
        String searchUrl = "https://geek-api-python.sellerwell.com/api/product/hotIndexNew";

        JSONObject param = new JSONObject();
        param.put("times", "2022-05-08");
        param.put("classification", "317778");
        param.put("rank_type", "coupang");
        HttpHeaders headers = RestUtil.getHeaderApplicationJson();
        headers.set("authorization", tocken);
        try {
            JSONObject object = RestUtil.request(searchUrl, HttpMethod.POST, headers, null, param, JSONObject.class).getBody();
            List<Map> list = (ArrayList) ((Map) object.get("data")).get("data");
            for (int i = 0; i < 3; i++) {
                Map map = (Map) list.get(i);
                String strDate = map.get("date").toString();
                List<Map> list1 = (ArrayList) map.get(strDate);
                List<GeekHotIndexNew> list2 = new ArrayList<>();
                if (list1.size() > 0) {
                    for (Map m : list1) {
                        GeekHotIndexNew geekHotIndexNew = new GeekHotIndexNew();
                        geekHotIndexNew.setClassification(m.get("classification").toString());
                        geekHotIndexNew.setComment(m.get("comment").toString());
                        geekHotIndexNew.setImages(m.get("images").toString());
                        geekHotIndexNew.setPrice(Double.parseDouble(m.get("price").toString()));
                        geekHotIndexNew.setProductId(m.get("product_id").toString());
                        geekHotIndexNew.setRank(m.get("rank").toString());
                        geekHotIndexNew.setRankType(m.get("rank_type").toString());
                        geekHotIndexNew.setStar(m.get("star").toString());
                        geekHotIndexNew.setState(m.get("state").toString());
                        geekHotIndexNew.setTitle(m.get("title").toString());
                        geekHotIndexNew.setUrl(m.get("url").toString());
                        geekHotIndexNew.setDate(DateUtils.parseDate(strDate,"yyyy-MM-dd"));
                        list2.add(geekHotIndexNew);
                    }
                }
                geekHotIndexNewService.saveBatch(list2);
            }

        } catch (Exception e) {
        }


        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        log.info(String.format("产品搜索,开始时间：%s-%s", df.format(startDate), df.format(new Date())));
    }

}

package org.jeecg.modules.geek.geekHotIndexNew.service;

import org.jeecg.modules.geek.geekHotIndexNew.entity.GeekHotIndexNew;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @Description: geek_hot_index_new
 * @Author: jeecg-boot
 * @Date:   2022-05-09
 * @Version: V1.0
 */
public interface IGeekHotIndexNewService extends IService<GeekHotIndexNew> {

}
